import launch
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():

    return launch.LaunchDescription([
        # Nodo 1
        Node(
            package='my_robot_controller',  # Nombre de tu paquete
            executable='programar',    # Nombre del ejecutable del nodo
            name='programar',          # Nombre del nodo
            output='screen'        # Mostrar salida en la terminal
        ),
        # Nodo 2
        Node(
            package='my_robot_controller',
            executable='cinematica',
            name='cinematica',
            output='screen'
        ),

        # Nodo 3
        Node(
            package='my_robot_controller',
            executable='manipulador',
            name='manipulador',
            output='screen'
        ),
    ])