import launch
from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import ExecuteProcess

def generate_launch_description():

    return launch.LaunchDescription([
        # Nodo 1
        Node(
            package='robot',  # Nombre de tu paquete
            executable='motores',    # Nombre del ejecutable del nodo
            name='motores',          # Nombre del nodo
            output='screen'        # Mostrar salida en la terminal
        ),
        # Nodo 2
        Node(
            package='robot',
            executable='cinematica',
            name='cinematica',
            output='screen'
        ),

        # Nodo 3
        Node(
            package='robot',
            executable='manipulador',
            name='manipulador',
            output='screen'
        ),
    ])