A = []

B = [1,2,3,4]

C = [5,6,7,8]

A.append(B)

try:
    D = [A[-1][0],A[-1][1],A[-1][2],A[-1][3]]
    print(D)
except:
    None