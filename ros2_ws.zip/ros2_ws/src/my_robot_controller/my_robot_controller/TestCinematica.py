import roboticstoolbox as rp
from spatialmath import SE3
from roboticstoolbox import *
import numpy as np

puma = rp.models.DH.Puma560

q = [0, -np.pi/2, np.pi/2, np.pi/2]

#T = SE3(0.2, 0.1, 0.05) * SE3.OA([-1, 0, 0], [0, 1, 0])
#T = SE3(0.15, 0.15, 0.05) * SE3.Ry(np.pi/2) * SE3.Rx(-np.pi/2)
T = SE3(0.15, 0.1, 0.1) * SE3.Ry(np.pi/2)

robot = DHRobot(
    [
        RevoluteDH(d=0.077, a=0, alpha= (-np.pi / 2), qlim=[-np.pi,np.pi]),
        RevoluteDH(d=0, a=0.13, alpha= 0, qlim=[-np.pi,0]),
        RevoluteDH(d=0, a=0.124, alpha= 0, qlim=[-3/4*np.pi,3/4*np.pi]),
        RevoluteDH(d=0, a=0.126, alpha= 0, qlim=[-1/4*np.pi,3/4*np.pi]),
    ],
    name="MyRobot",
)

#A = robot.fkine([0, 0, 0, np.pi/2])

#D = robot.fkine(q)

mask = [1,1,1,1,0,0]

solver = robot.ikine_LM(T,q,50,500,mask=mask,joint_limits=True,tol=0.001,)

joints = solver.q

#C = robot.fkine(joints)

#print(D)

#print(T)
print(solver)
#print(C)